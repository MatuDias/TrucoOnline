public class WarningShutDown  extends Warning
{}
