import java.io.Serializable;

public class Warning implements Serializable, Cloneable {
}
