public class WarningStart extends Warning{
}
